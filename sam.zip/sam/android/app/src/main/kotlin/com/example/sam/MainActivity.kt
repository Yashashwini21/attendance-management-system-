package com.example.sam

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

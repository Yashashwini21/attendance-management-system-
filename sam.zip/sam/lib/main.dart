import 'package:flutter/material.dart';
import 'super_admin_login_page.dart';
import 'sub_admin_login_page.dart';
import 'student_login_page.dart';
import 'super_admin_dashboard.dart';
import 'sub_admin_dashboard.dart';
import 'student_dashboard.dart';
import 'role_manager.dart';
import 'overview_page.dart';
import 'manage_users_page.dart';
import 'reports_page.dart';
import 'settings_page.dart';


void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Attendance Management System',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/login',
      routes: {
        '/login': (context) => LoginSelectionPage(),
        '/super_admin_login': (context) => SuperAdminLoginPage(),
        '/sub_admin_login': (context) => SubAdminLoginPage(),
        '/student_login': (context) => StudentLoginPage(),
        '/super_admin_dashboard': (context) => SuperAdminDashboard(),
        '/sub_admin_dashboard': (context) => SubAdminDashboard(),
        '/student_dashboard': (context) => StudentDashboard(),
        '/overview': (context) => OverviewPage(),
        '/manage_users': (context) => ManageUsersPage(),
        '/reports': (context) => ReportsPage(),
        '/settings': (context) => SettingsPage(),
      },
    );
  }
}

class LoginSelectionPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Select Login Role'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/super_admin_login');
              },
              child: Text('Super Admin Login'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/sub_admin_login');
              },
              child: Text('Sub Admin Login'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/student_login');
              },
              child: Text('Student Login'),
            ),
          ],
        ),
      ),
    );
  }
}

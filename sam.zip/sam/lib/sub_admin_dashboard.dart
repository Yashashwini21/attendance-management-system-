import 'package:flutter/material.dart';

class SubAdminDashboard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Sub Admin Dashboard'),
      ),
      body: Center(
        child: Text('Welcome to the Sub Admin Dashboard!'),
      ),
    );
  }
}

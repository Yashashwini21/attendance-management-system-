class RoleManager {
  static bool authenticateSuperAdmin(String email, String password) {
    // Implement authentication logic for Super Admin
    return email == 'superadmin@example.com' && password == 'superadmin123';
  }

  static bool authenticateSubAdmin(String email, String password) {
    // Implement authentication logic for Sub Admin
    return email == 'subadmin@example.com' && password == 'subadmin123';
  }

  static bool authenticateStudent(String email, String password) {
    // Implement authentication logic for Student
    return email == 'student@example.com' && password == 'student123';
  }
}

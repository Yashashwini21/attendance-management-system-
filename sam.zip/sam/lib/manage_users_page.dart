import 'package:flutter/material.dart';

class ManageUsersPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Manage Users'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ElevatedButton(
              onPressed: () {
                // Add sub admin logic here
              },
              child: Text('Add Sub Admin'),
            ),
            SizedBox(height: 8),
            ElevatedButton(
              onPressed: () {
                // Remove sub admin logic here
              },
              child: Text('Remove Sub Admin'),
            ),
            SizedBox(height: 8),
            ElevatedButton(
              onPressed: () {
                // View student accounts logic here
              },
              child: Text('View Student Accounts'),
            ),
          ],
        ),
      ),
    );
  }
}

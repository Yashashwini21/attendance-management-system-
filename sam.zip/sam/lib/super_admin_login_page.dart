import 'package:flutter/material.dart';
import 'role_manager.dart';

class SuperAdminLoginPage extends StatelessWidget {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Super Admin Login'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _emailController,
              decoration: InputDecoration(labelText: 'Email'),
            ),
            TextField(
              controller: _passwordController,
              decoration: InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Perform authentication and navigate to super admin dashboard
                if (RoleManager.authenticateSuperAdmin(
                  _emailController.text,
                  _passwordController.text,
                )) {
                  Navigator.pushReplacementNamed(context, '/super_admin_dashboard');
                } else {
                  // Handle authentication failure
                }
              },
              child: Text('Login'),
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';

class OverviewPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Overview'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Total number of registered students: 1200', style: TextStyle(fontSize: 18)),
            SizedBox(height: 10),
            Text('Total number of classes: 35', style: TextStyle(fontSize: 18)),
            SizedBox(height: 10),
            Text('Overall attendance rate: 95%', style: TextStyle(fontSize: 18)),
          ],
        ),
      ),
    );
  }
}
